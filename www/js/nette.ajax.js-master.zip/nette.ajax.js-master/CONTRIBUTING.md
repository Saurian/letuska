### Please ;) ...

1. Create pull requests from specific branches, not `master`.

2. Write good commit messages (if you use Github embedded editor for committing, the default commit message offered to you is ussually not good enough). You may get inspired in [Pre-emptive commit comments](http://arialdomartini.wordpress.com/2012/09/03/pre-emptive-commit-comments/) [EN] or [Commitujte jako profík!](http://www.zdrojak.cz/clanky/commitujte-jako-profik/) [CZ].

3. Use English and keep coding style.

### Thanks for contribution!
